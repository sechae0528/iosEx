//
//  ViewController.swift
//  test2
//
//  Created by 스마트금융5 on 2018. 4. 25..
//  Copyright © 2018년 cse. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myLabelText: UILabel!
    @IBOutlet weak var myButton: UIButton!
    @IBOutlet weak var myImgView: UIImageView!
    @IBOutlet weak var mySwitch: UISwitch!
    @IBOutlet weak var myTextView: UITextView!
    
    func onFinish(data: Data?, response: URLResponse?, error: Error?) {
        // Raw 데이터를 UTF8 문자열로 변환
        if let nsstr = NSString(data: data!, encoding: String.Encoding.utf8.rawValue) {
            // UTF8 문자열로 변환되면 일반적인 문자열로 변환
            let str = String(nsstr)
            // 문자열 출력
            print("문자열=[\(str)]")
            if let response = response as? HTTPURLResponse {
                if response.statusCode == 200 {
                    print("Success")
                    
                    DispatchQueue.main.sync(execute: {
                        self.myTextView.text = str
                    })
                    
                }
                else{
                    print("Error")
                }
            }
        }
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        myImgView.image = UIImage(named: "fintech.jpg")
        
        if let url = URL(string: "https://www.google.com/robots.txt") {
            // url이 nil이 아니라면 URLSession 객체 생성
            let urlSession = URLSession.shared
            // 데이터를 읽어들이는 태스크를 완료하면 completionHandler 처리가 수행됩니다.
            let task = urlSession.dataTask(with: url, completionHandler: onFinish)
            task.resume()
            
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnTouchUp(_ sender: Any) {
        myLabelText.text = "채성은"
    }
    
    @IBAction func switchChanged(_ sender: Any) {
        if(mySwitch.isOn == true){
            myImgView.image = UIImage(named: "fintech.jpg")
            
            
        }else{
            myImgView.image = UIImage(named: "castle.jpg")
           
            
        }
        
    }
    

}

